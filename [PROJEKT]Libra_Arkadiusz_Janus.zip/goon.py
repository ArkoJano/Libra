def go_on():
    """ Funkcja zatrzymuje dzialanie programu czekajac na dzialanie uzytkownika """

    input("""        |   Nacisnij enter aby kontynuowac...                               |
        +-------------------------------------------------------------------+""")
