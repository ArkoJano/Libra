from main import main

# """ Plik uruchamiajacy caly program """

if __name__ == "__main__":
    main()