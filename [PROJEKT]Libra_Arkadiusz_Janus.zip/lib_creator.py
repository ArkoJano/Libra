from library import *
from book import *

library = Library()